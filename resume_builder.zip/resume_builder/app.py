# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 19:52:54 2024

@author: admin
"""

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        skills = request.form['skills']
        experience = request.form['experience']
        education = request.form['education']

        # Render the resume with the data
        return render_template('resume.html', name=name, email=email, phone=phone, skills=skills, experience=experience, education=education)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
